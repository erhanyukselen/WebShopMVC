﻿namespace WebShopMVC.Models
{
    public static class Other
    {
        public const string Role_Person = "Person";
        public const string Role_Admin = "Admin";
        public const string Role_User = "User";

    }
}
