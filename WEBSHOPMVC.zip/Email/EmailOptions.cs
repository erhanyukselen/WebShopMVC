﻿namespace WebShopMVC.Email
{
    public class EmailOptions
    {
        public string SenGridKey { get; set; }
    }
}
